---
name: Vitality Flux
colors:
  surface: '#f8f9fa'
  surface-dim: '#d9dadb'
  surface-bright: '#f8f9fa'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f4f5'
  surface-container: '#edeeef'
  surface-container-high: '#e7e8e9'
  surface-container-highest: '#e1e3e4'
  on-surface: '#191c1d'
  on-surface-variant: '#3c4a42'
  inverse-surface: '#2e3132'
  inverse-on-surface: '#f0f1f2'
  outline: '#6c7a71'
  outline-variant: '#bbcabf'
  surface-tint: '#006c49'
  primary: '#006c49'
  on-primary: '#ffffff'
  primary-container: '#10b981'
  on-primary-container: '#00422b'
  inverse-primary: '#4edea3'
  secondary: '#2b6954'
  on-secondary: '#ffffff'
  secondary-container: '#adedd3'
  on-secondary-container: '#306d58'
  tertiary: '#416656'
  on-tertiary: '#ffffff'
  tertiary-container: '#84ab98'
  on-tertiary-container: '#1b3f31'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#6ffbbe'
  primary-fixed-dim: '#4edea3'
  on-primary-fixed: '#002113'
  on-primary-fixed-variant: '#005236'
  secondary-fixed: '#b0f0d6'
  secondary-fixed-dim: '#95d3ba'
  on-secondary-fixed: '#002117'
  on-secondary-fixed-variant: '#0b513d'
  tertiary-fixed: '#c3ecd7'
  tertiary-fixed-dim: '#a8cfbc'
  on-tertiary-fixed: '#002115'
  on-tertiary-fixed-variant: '#294e3f'
  background: '#f8f9fa'
  on-background: '#191c1d'
  surface-variant: '#e1e3e4'
  status-available: '#10B981'
  status-offline: '#EF4444'
  accent-warning: '#F59E0B'
  surface-card: '#FFFFFF'
  text-main: '#111827'
  text-muted: '#6B7280'
typography:
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '700'
    lineHeight: 28px
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-bold:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.05em
  stat-display:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '800'
    lineHeight: 40px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 4px
  container-margin: 16px
  gutter: 12px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 24px
---

## Brand & Style

The design system is engineered for the **MedEasy Rider Portal**, focusing on the dual pillars of **reliability** and **efficiency**. Given that riders are often in motion, the visual language prioritizes high legibility, immediate scanability, and a sense of "health-tech" professionalism.

The chosen style is **Corporate Modern with a Tactile Edge**. It utilizes a clean, "medical-grade" white foundation punctuated by vibrant, high-contrast greens. The interface avoids unnecessary decoration, instead using generous whitespace and subtle depth to guide the rider through their workflow—from pickup to delivery—without cognitive overload. The emotional goal is to make the rider feel like a vital, trusted link in the healthcare chain.

## Colors

The color palette is rooted in a "Safety Green" spectrum. 
- **Primary Green (#10B981):** Used for critical actions (Accept, Complete) and the "Available" status. It must maintain a high contrast ratio against white backgrounds.
- **Deep Emerald (#064E3B):** Reserved for high-level branding and primary typography to ensure groundedness and authority.
- **Mint Tint (#D1FAE5):** Used for background fills on active states or success alerts, providing a soft contrast to the primary green.
- **Status Indicators:** "Available" uses the primary green, while "Offline" uses a high-visibility Red (#EF4444) to ensure the rider is immediately aware of their connectivity status.

## Typography

**Plus Jakarta Sans** is the sole typeface for this design system. Its modern, slightly rounded geometric forms provide a friendly yet professional appearance that is highly legible on mobile screens under varying light conditions.

- **Hierarchy:** Use `stat-display` for daily earnings to provide immediate gratification. 
- **Clarity:** Navigation and addresses use `body-lg` with medium weights to ensure riders can read locations at a glance.
- **Labels:** Use uppercase `label-bold` for status tags (e.g., "PENDING", "COMPLETED") to distinguish them from interactive body text.

## Layout & Spacing

This design system follows a **mobile-first, PWA-centric fluid layout**. The interface is optimized for one-handed use, with primary interactive elements placed within the "thumb zone" (lower two-thirds of the screen).

- **Grid:** A simple fluid grid with 16px side margins on mobile. On tablet/desktop, the content area is capped at 600px and centered to maintain the vertical "feed" feel characteristic of delivery apps.
- **Rhythm:** An 8px base unit (4px for micro-adjustments) creates a consistent vertical rhythm.
- **Touch Targets:** All buttons and interactive toggles must have a minimum height of 48px to accommodate rapid interaction in outdoor environments.

## Elevation & Depth

To maintain a clean, medical aesthetic, the design system avoids heavy shadows. Instead, it uses **Soft Ambient Shadows** and **Tonal Layering**.

- **Surface Levels:** The background uses the `neutral-color-hex`. Interactive cards and containers use a pure `#FFFFFF` background.
- **Shadow Style:** Cards use a very soft, diffused shadow: `0px 4px 12px rgba(0, 0, 0, 0.05)`.
- **Active State:** When a rider is "Available," the main dashboard may feature a subtle glow effect using the primary green to reinforce the active status.
- **Interaction:** Elevated elements should appear to "lift" slightly on tap, using a slightly more pronounced shadow to indicate responsiveness.

## Shapes

The shape language is **Rounded (Level 2)**. This balance avoids the harshness of sharp corners while maintaining the structured feel of a professional utility tool.

- **Standard Elements:** Buttons and input fields use a `0.5rem` (8px) radius.
- **Large Containers:** Cards and modals use `rounded-lg` (16px) to create a soft, modern container for information.
- **Indicators:** Availability toggles and status dots use a fully rounded/pill shape to distinguish them from structural layout elements.

## Components

### Buttons
- **Primary:** Solid `#10B981` with white text. High-contrast and bold.
- **Secondary/Reject:** Outlined style with `#EF4444` for rejection or `#6B7280` for secondary actions.
- **Full Width:** On mobile, primary actions (Accept/Complete) should be full-width "sticky" buttons at the bottom of the viewport.

### Cards
- **Order Card:** White background, 16px padding, subtle shadow. Pickup and Drop locations should be separated by a vertical dotted line to visualize the route.
- **Earning Card:** Uses `stat-display` for the currency amount, centered for maximum impact.

### Status Indicators
- **Available Toggle:** A prominent switch at the top of the dashboard. When "Available," the status dot pulses slightly.
- **Badge:** Small, rounded-pill badges used in tables and lists to indicate "Verfied" or "Unverified" profiles.

### Input Fields
- Underlined or softly bordered with 16px internal padding. Labels should be floating or positioned clearly above the field to ensure riders know exactly what data is being entered (especially for OTP).

### Navigation
- A simple Bottom Navigation Bar for PWA users with three icons: Dashboard, Orders, and Profile. This ensures the most important views are always one tap away.