

// ==============================
// SIDEBAR TOGGLE
// ==============================


function toggleSidebar(){

    document
    .querySelector(".sidebar")
    .classList.toggle("active");

}





// ==============================
// ANALYTICS DATA
// ==============================


const revenueData = {


January:45000,

February:62000,

March:75000,

April:58000,

May:82000,

June:90000,

July:85000,

August:78000,

September:95000,

October:88000,

November:105000,

December:120000


};






const medicineSales=[


{
medicine:"Paracetamol 500mg",
category:"Tablet",
quantity:120,
revenue:15000
},


{
medicine:"Dolo 650",
category:"Tablet",
quantity:85,
revenue:12000
},


{
medicine:"Vitamin C",
category:"Capsule",
quantity:150,
revenue:18000
},


{
medicine:"Amoxicillin",
category:"Capsule",
quantity:70,
revenue:14000
},


{
medicine:"Cough Syrup",
category:"Syrup",
quantity:90,
revenue:10000
},


{
medicine:"Insulin Injection",
category:"Injection",
quantity:45,
revenue:25000
},


{
medicine:"Metformin",
category:"Tablet",
quantity:100,
revenue:13000
},


{
medicine:"Pantoprazole",
category:"Capsule",
quantity:60,
revenue:9000
},


{
medicine:"Azithromycin",
category:"Tablet",
quantity:75,
revenue:16000
}



];







// ==============================
// CANVAS GRAPH
// ==============================


const canvas =
document.getElementById("revenueChart");


const ctx =
canvas.getContext("2d");




function drawChart(){



ctx.clearRect(
0,
0,
canvas.width,
canvas.height
);



canvas.width=
canvas.offsetWidth;



canvas.height=
350;




let months=
Object.keys(revenueData);



let values=
Object.values(revenueData);





let max=
Math.max(...values);





ctx.beginPath();


ctx.moveTo(50,300);



values.forEach((value,index)=>{


let x =
80+(index*60);



let y =
300 -
(value/max)*220;



ctx.lineTo(x,y);



ctx.fillStyle="#2e7d32";


ctx.font="12px Arial";


ctx.fillText(
months[index].substring(0,3),
x-10,
330
);



ctx.fillText(
"₹"+value/1000+"k",
x-20,
y-15
);



});



ctx.strokeStyle="#2e7d32";

ctx.lineWidth=3;


ctx.stroke();



}





drawChart();









// ==============================
// MONTH FILTER
// ==============================


const monthFilter =
document.getElementById(
"monthFilter"
);



monthFilter.addEventListener(
"change",
()=>{


let selected =
monthFilter.value;




if(selected==="all"){


document
.getElementById(
"monthlyRevenue"
)
.innerText=
"₹85,000";


}


else{


document
.getElementById(
"monthlyRevenue"
)
.innerText=

"₹"+
revenueData[selected];


}



});









// ==============================
// CATEGORY FILTER
// ==============================


const categoryFilter =
document.getElementById(
"categoryFilter"
);



categoryFilter.addEventListener(
"change",
displaySales
);





function displaySales(){


let category =
categoryFilter.value;



let data =
medicineSales.filter(item=>{


return category==="all"

||

item.category===category;


});



let table =
document.getElementById(
"salesData"
);



table.innerHTML="";





data.forEach(item=>{


table.innerHTML+=`


<tr>


<td>

${item.medicine}

</td>



<td>

${item.category}

</td>



<td>

${item.quantity}

</td>



<td>

₹${item.revenue}

</td>



</tr>


`;


});


}




displaySales();









// ==============================
// DOWNLOAD CSV REPORT
// ==============================


document
.getElementById(
"downloadBtn"
)
.addEventListener(
"click",
downloadReport
);






function downloadReport(){



let csv =

"Medicine,Category,Quantity Sold,Revenue\n";





medicineSales.forEach(item=>{


csv +=

`${item.medicine},
${item.category},
${item.quantity},
${item.revenue}
\n`;


});





let blob =
new Blob(
[csv],
{
type:"text/csv"
}
);



let url =
URL.createObjectURL(blob);



let link =
document.createElement("a");



link.href=url;



link.download=
"pharmacy-sales-report.csv";



link.click();



URL.revokeObjectURL(url);



}