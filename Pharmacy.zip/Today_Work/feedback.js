// ==============================
// SIDEBAR TOGGLE
// ==============================

function toggleSidebar(){

    document
    .querySelector(".sidebar")
    .classList.toggle("active");

}



// ==============================
// CUSTOMER FEEDBACK DATABASE
// ==============================


const customers=[

"Rahul Kumar",
"Priya Sharma",
"Arun Patel",
"Sneha Reddy",
"Vikram Singh",
"Anjali Verma",
"Karan Mehta",
"Neha Joshi",
"Rohit Kumar",
"Pooja Sharma",
"Amit Singh",
"Deepika Rao",
"Manoj Verma",
"Kavya Reddy",
"Harish Patel"

];



const comments=[

"Medicines were delivered quickly and packaging was excellent.",

"Excellent pharmacy service. Medicines were genuine and delivery was fast.",

"Very smooth ordering experience with helpful customer support.",

"Received my medicines on time. Highly satisfied with the service.",

"Affordable prices and good quality medicines.",

"Fast delivery and professional service from the pharmacy team.",

"Very easy to order medicines online. Great experience.",

"The pharmacy staff was very helpful and responsive.",

"Good availability of medicines and quick delivery.",

"Excellent service. Will definitely order again.",

"Trusted pharmacy with genuine medicines.",

"Customer support team solved my query immediately.",

"Great experience with timely delivery and proper packaging."

];






let feedbacks=[];



// ==============================
// GENERATE HIGH RATING REVIEWS
// ==============================


function generateFeedback(){


for(let i=1;i<=50;i++){



let rating;



// Mostly 5 and 4 stars

let random =
Math.random();



if(random < 0.65){

    rating = 5;

}

else if(random < 0.95){

    rating = 4;

}

else{

    rating = 3;

}






feedbacks.push({


id:i,


name:

customers[
Math.floor(
Math.random()
*
customers.length
)
],




date:

`${i}-07-2026`,





rating:rating,





comment:

comments[
Math.floor(
Math.random()
*
comments.length
)
]



});



}



}



generateFeedback();








// ==============================
// SUMMARY CALCULATION
// ==============================


document
.getElementById("totalReviews")
.innerText =
feedbacks.length;




let average =


feedbacks.reduce(

(total,item)=>{

return total + item.rating;

},

0

)

/
feedbacks.length;




document
.getElementById("avgRating")
.innerText =

average.toFixed(1);








// ==============================
// PAGINATION
// ==============================


let currentPage=1;


const recordsPerPage=6;



let filteredFeedback=[];







// ==============================
// SEARCH + FILTER
// ==============================


const searchInput =

document.getElementById(
"searchFeedback"
);



const ratingFilter =

document.getElementById(
"ratingFilter"
);





searchInput.addEventListener(

"keyup",

applyFilters

);





ratingFilter.addEventListener(

"change",

applyFilters

);







function applyFilters(){



let search =

searchInput
.value
.toLowerCase();





let rating =

ratingFilter.value;







filteredFeedback =


feedbacks.filter(item=>{





let searchMatch =


item.name
.toLowerCase()
.includes(search)

||

item.comment
.toLowerCase()
.includes(search);







let ratingMatch =


rating==="all"

||

item.rating == rating;







return searchMatch && ratingMatch;



});




currentPage=1;



displayFeedback();



}








// ==============================
// DISPLAY FEEDBACK CARDS
// ==============================



function displayFeedback(){



const container =

document.getElementById(
"feedbackContainer"
);



container.innerHTML="";






let start =

(currentPage-1)
*
recordsPerPage;




let end =

start+
recordsPerPage;





let pageData =


filteredFeedback
.slice(
start,
end
);






pageData.forEach(item=>{


let stars="";



for(let i=1;i<=5;i++){



if(i<=item.rating){


stars +=

`
<i class="fa-solid fa-star"></i>
`;

}

else{


stars +=

`
<i class="fa-regular fa-star"></i>
`;

}


}





container.innerHTML +=`


<div class="feedback-card">


<div class="customer">


<i class="fa-solid fa-circle-user"></i>



<div>

<h3>

${item.name}

</h3>



<span class="date">

${item.date}

</span>


</div>


</div>





<div class="stars">

${stars}

</div>





<p class="comment">

${item.comment}

</p>




</div>


`;



});





createPagination();



}










// ==============================
// PAGINATION
// ==============================


function createPagination(){



let pagination =

document.getElementById(
"pagination"
);



pagination.innerHTML="";





let pages =


Math.ceil(

filteredFeedback.length /

recordsPerPage

);






let prev =

document.createElement(
"button"
);



prev.innerText="Previous";



prev.onclick=()=>{


if(currentPage>1){


currentPage--;

displayFeedback();


}


};




pagination.appendChild(prev);








for(let i=1;i<=pages;i++){



let btn =

document.createElement(
"button"
);



btn.innerText=i;




if(i===currentPage)

btn.classList.add(
"active"
);




btn.onclick=()=>{


currentPage=i;


displayFeedback();


};



pagination.appendChild(btn);



}








let next =

document.createElement(
"button"
);



next.innerText="Next";



next.onclick=()=>{


if(currentPage<pages){


currentPage++;


displayFeedback();


}



};



pagination.appendChild(next);



}








// INITIAL LOAD


applyFilters();