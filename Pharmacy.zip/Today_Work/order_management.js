// ==============================
// SIDEBAR TOGGLE
// ==============================

function toggleSidebar(){

    document
    .querySelector(".sidebar")
    .classList.toggle("active");

}



// ==============================
// ORDER DATABASE
// ==============================


const customers = [

"Rahul Kumar",
"Priya Sharma",
"Arun Patel",
"Sneha Reddy",
"Vikram Singh",
"Anjali Verma",
"Karan Mehta",
"Neha Joshi",
"Rohit Kumar",
"Pooja Sharma"

];


const medicines = [

"Paracetamol 500mg",
"Vitamin C Capsule",
"Azithromycin",
"Cough Syrup",
"Insulin Injection",
"Amoxicillin",
"Dolo 650",
"Pantoprazole",
"Calcium Tablets",
"Metformin"

];



let orders=[];




let orderId=1001;



// Generate Orders


function generateOrders(){


let statuses=[

"Pending",
"Processing",
"Shipped",
"Cancelled"

];



statuses.forEach(status=>{


for(let i=0;i<20;i++){


orders.push({


id:"ORD"+orderId++,


customer:
customers[
Math.floor(
Math.random()*customers.length
)
],



date:
`${10+i}-07-2026`,



medicine:
medicines[
Math.floor(
Math.random()*medicines.length
)
],



quantity:
Math.floor(
Math.random()*5
)+1,



amount:
Math.floor(
Math.random()*900
)+100,



status:status


});


}



});


}


generateOrders();





// ==============================
// COUNTS
// ==============================


document.getElementById("totalOrders")
.innerText=orders.length;



document.getElementById("pendingCount")
.innerText=
orders.filter(
order=>order.status==="Pending"
).length;




document.getElementById("processingCount")
.innerText=
orders.filter(
order=>order.status==="Processing"
).length;




document.getElementById("shippedCount")
.innerText=
orders.filter(
order=>order.status==="Shipped"
).length;






// ==============================
// TABLE SETTINGS
// ==============================


let currentStatus="Pending";

let currentPage=1;

const recordsPerPage=10;


let filteredOrders=[];




// ==============================
// CHANGE TAB
// ==============================


function changeStatus(status,button){


currentStatus=status;


currentPage=1;



document
.querySelectorAll(".tab")
.forEach(tab=>{

tab.classList.remove("active");

});



button.classList.add("active");



filterOrders();


}







// ==============================
// FILTER ORDERS
// ==============================


const searchInput =
document.getElementById("searchOrder");



searchInput.addEventListener(
"keyup",
filterOrders
);





function filterOrders(){



let text=
searchInput.value
.toLowerCase();




filteredOrders =
orders.filter(order=>{


return (

order.status===currentStatus

&&

(

order.id
.toLowerCase()
.includes(text)


||

order.customer
.toLowerCase()
.includes(text)


||

order.medicine
.toLowerCase()
.includes(text)

)

);


});



currentPage=1;


displayOrders();


}







// ==============================
// DISPLAY ORDERS
// ==============================


function displayOrders(){



let table =
document.getElementById("orderTable");



table.innerHTML="";




let start =
(currentPage-1)
*
recordsPerPage;



let end =
start+recordsPerPage;



let pageData =
filteredOrders.slice(start,end);





pageData.forEach(order=>{


let action="";



if(order.status==="Pending"){


action=`

<button class="action-btn approve"
onclick="updateOrder('${order.id}','Processing')">

<i class="fa-solid fa-check"></i>

Approve

</button>


<button class="action-btn reject"
onclick="updateOrder('${order.id}','Cancelled')">

<i class="fa-solid fa-ban"></i>

Reject

</button>

`;



}

else{


action="-";


}






table.innerHTML+=`


<tr>


<td>${order.id}</td>


<td>${order.customer}</td>


<td>${order.date}</td>


<td>${order.medicine}</td>


<td>${order.quantity}</td>


<td>₹${order.amount}</td>



<td>

<span class="status ${order.status.toLowerCase()}">

${order.status}

</span>


</td>



<td>

${action}

</td>



</tr>


`;



});



createPagination();



}







// ==============================
// PAGINATION
// ==============================


function createPagination(){


let container =
document.getElementById("pagination");



container.innerHTML="";



let pages =
Math.ceil(
filteredOrders.length /
recordsPerPage
);



let previous =
document.createElement("button");


previous.innerText="Previous";



previous.onclick=()=>{


if(currentPage>1){

currentPage--;

displayOrders();

}


};



container.appendChild(previous);






for(let i=1;i<=pages;i++){


let btn =
document.createElement("button");


btn.innerText=i;



if(i===currentPage)

btn.classList.add("active-page");




btn.onclick=()=>{


currentPage=i;

displayOrders();


};



container.appendChild(btn);


}






let next =
document.createElement("button");


next.innerText="Next";



next.onclick=()=>{


if(currentPage<pages){


currentPage++;

displayOrders();


}


};



container.appendChild(next);



}







// ==============================
// APPROVE / REJECT
// ==============================


function updateOrder(id,newStatus){



let order =
orders.find(
item=>item.id===id
);



if(order){


order.status=newStatus;



showPopup(

`Order ${id} ${newStatus}`

);


filterOrders();


}



}






// ==============================
// POPUP
// ==============================


function showPopup(message){


let popup =
document.getElementById("popup");



popup.innerHTML=

`

<i class="fa-solid fa-circle-check"></i>

${message}

`;



popup.style.display="block";



setTimeout(()=>{


popup.style.display="none";


},3000);


}







// INITIAL LOAD


filterOrders();