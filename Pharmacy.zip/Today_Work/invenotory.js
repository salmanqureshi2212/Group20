// ==============================
// SIDEBAR TOGGLE
// ==============================

function toggleSidebar(){

    const sidebar =
    document.querySelector(".sidebar");

    sidebar.classList.toggle("active");

}



// ==============================
// MEDICINE DATABASE
// ==============================


const medicines = [


{
name:"Paracetamol 500mg",
category:"Tablet",
quantity:120,
price:50,
expiry:"12-08-2027",
status:"Available"
},


{
name:"Vitamin C",
category:"Capsule",
quantity:40,
price:120,
expiry:"05-06-2027",
status:"Low Stock"
},


{
name:"Azithromycin",
category:"Antibiotic",
quantity:8,
price:200,
expiry:"10-02-2026",
status:"Expiring Soon"
},


{
name:"Cough Syrup",
category:"Syrup",
quantity:75,
price:90,
expiry:"15-11-2027",
status:"Available"
},


{
name:"Insulin Injection",
category:"Injection",
quantity:15,
price:450,
expiry:"20-03-2027",
status:"Low Stock"
},


{
name:"Amoxicillin",
category:"Antibiotic",
quantity:90,
price:180,
expiry:"11-04-2027",
status:"Available"
},


{
name:"Ibuprofen",
category:"Tablet",
quantity:60,
price:70,
expiry:"09-09-2027",
status:"Available"
},


{
name:"Cetirizine",
category:"Tablet",
quantity:55,
price:40,
expiry:"01-05-2027",
status:"Available"
},


{
name:"Dolo 650",
category:"Tablet",
quantity:100,
price:35,
expiry:"22-07-2027",
status:"Available"
},


{
name:"Calcium Tablets",
category:"Tablet",
quantity:45,
price:150,
expiry:"18-12-2027",
status:"Low Stock"
},


{
name:"ORS Powder",
category:"Syrup",
quantity:80,
price:25,
expiry:"25-10-2027",
status:"Available"
},


{
name:"Pantoprazole",
category:"Capsule",
quantity:65,
price:90,
expiry:"14-03-2027",
status:"Available"
},


{
name:"Metformin",
category:"Tablet",
quantity:70,
price:110,
expiry:"19-08-2027",
status:"Available"
},


{
name:"Aspirin",
category:"Tablet",
quantity:30,
price:60,
expiry:"30-06-2027",
status:"Low Stock"
},


{
name:"Multivitamin Capsule",
category:"Capsule",
quantity:95,
price:200,
expiry:"17-01-2028",
status:"Available"
},


// More records


{
name:"Eye Drops",
category:"Syrup",
quantity:35,
price:80,
expiry:"21-11-2027",
status:"Low Stock"
},


{
name:"Vitamin D3",
category:"Capsule",
quantity:120,
price:250,
expiry:"15-05-2028",
status:"Available"
},


{
name:"Pain Relief Gel",
category:"Tablet",
quantity:50,
price:90,
expiry:"12-02-2027",
status:"Available"
},


{
name:"Antiseptic Liquid",
category:"Syrup",
quantity:40,
price:100,
expiry:"10-10-2027",
status:"Available"
},


{
name:"Blood Pressure Tablets",
category:"Tablet",
quantity:75,
price:300,
expiry:"20-09-2027",
status:"Available"
}


];



// ==============================
// PAGINATION SETTINGS
// ==============================


let currentPage = 1;

const recordsPerPage = 10;



let filteredMedicines = medicines;



// ==============================
// DISPLAY DATA
// ==============================


function displayMedicines(){


const table =
document.getElementById("medicineData");



table.innerHTML="";



let start =
(currentPage-1)
*
recordsPerPage;



let end =
start + recordsPerPage;



let records =
filteredMedicines.slice(start,end);





records.forEach(medicine=>{


let row =
`

<tr>

<td>${medicine.name}</td>

<td>${medicine.category}</td>

<td>${medicine.quantity}</td>

<td>₹${medicine.price}</td>

<td>${medicine.expiry}</td>


<td>

<span class="${getStatusClass(medicine.status)}">

${medicine.status}

</span>


</td>


</tr>

`;



table.innerHTML += row;



});


updatePagination();


}




// ==============================
// STATUS COLORS
// ==============================


function getStatusClass(status){


if(status==="Available")
return "available";


if(status==="Low Stock")
return "low";


return "expiry";


}



// ==============================
// PAGINATION
// ==============================


function updatePagination(){


const pagination =
document.querySelector(".pagination");



pagination.innerHTML="";



let totalPages =
Math.ceil(
filteredMedicines.length /
recordsPerPage
);





let previous =
document.createElement("button");


previous.innerText="Previous";


previous.onclick=()=>{


if(currentPage>1){

currentPage--;

displayMedicines();

}

};



pagination.appendChild(previous);





for(let i=1;i<=totalPages;i++){


let button =
document.createElement("button");


button.innerText=i;



if(i===currentPage){

button.classList.add("active-page");

}



button.onclick=()=>{


currentPage=i;

displayMedicines();


};



pagination.appendChild(button);


}





let next =
document.createElement("button");


next.innerText="Next";



next.onclick=()=>{


if(currentPage<totalPages){

currentPage++;

displayMedicines();

}


};



pagination.appendChild(next);



}



// ==============================
// SEARCH + FILTER
// ==============================


const search =
document.getElementById("searchMedicine");


const category =
document.getElementById("categoryFilter");




function filterData(){



let searchText =
search.value.toLowerCase();



let selectedCategory =
category.value;




filteredMedicines =
medicines.filter(item=>{


return (

item.name
.toLowerCase()
.includes(searchText)

&&


(
selectedCategory==="all"

||

item.category===selectedCategory

)


);


});



currentPage=1;


displayMedicines();


}





search.addEventListener(
"keyup",
filterData
);



category.addEventListener(
"change",
filterData
);




// INITIAL LOAD

displayMedicines();