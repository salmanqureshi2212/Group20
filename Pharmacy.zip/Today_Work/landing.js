const startButton = document.getElementById("startBtn");


startButton.addEventListener("click",()=>{


window.location.href="auth.html";


});
