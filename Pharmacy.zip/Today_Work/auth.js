// Toggle Buttons

const loginTab = document.getElementById("loginTab");
const registerTab = document.getElementById("registerTab");

const loginForm = document.getElementById("loginForm");
const registerForm = document.getElementById("registerForm");



loginTab.addEventListener("click", () => {

    loginTab.classList.add("active");
    registerTab.classList.remove("active");

    loginForm.classList.remove("hidden");
    registerForm.classList.add("hidden");

});



registerTab.addEventListener("click", () => {

    registerTab.classList.add("active");
    loginTab.classList.remove("active");

    registerForm.classList.remove("hidden");
    loginForm.classList.add("hidden");

});




// Login Redirect

loginForm.addEventListener("submit", function(e){

    e.preventDefault();

    window.location.href = "./inventory.html";

});




// Register Redirect

const registerBtn = document.getElementById("registerBtn");


registerBtn.addEventListener("click", function(){

    window.location.href = "./inventory.html";

});




// Image Preview

const profileImage = document.getElementById("profileImage");
const preview = document.getElementById("preview");


profileImage.addEventListener("change", function(){


    const file = this.files[0];


    if(file){

        const reader = new FileReader();


        reader.onload = function(e){

            preview.src = e.target.result;

            preview.style.display = "block";

        };


        reader.readAsDataURL(file);

    }


});




// Toast Function (optional)

function showToast(message){

    const toast = document.getElementById("toast");

    toast.innerHTML = message;

    toast.style.display = "block";


    setTimeout(()=>{

        toast.style.display = "none";

    },2000);

}