// ============================
// SIDEBAR TOGGLE
// ============================


function toggleSidebar(){

    document
    .querySelector(".sidebar")
    .classList.toggle("active");

}





// ============================
// IMAGE PREVIEW
// ============================


const imageInput =
document.getElementById("medicineImage");


const imagePreview =
document.getElementById("imagePreview");




imageInput.addEventListener(
"change",
function(){


const file=this.files[0];


if(file){


const reader =
new FileReader();



reader.onload=function(e){


imagePreview.src=e.target.result;


}



reader.readAsDataURL(file);


}


});






// ============================
// SAVE MEDICINE
// ============================


const form =
document.getElementById("medicineForm");



form.addEventListener(
"submit",
function(e){


e.preventDefault();




let medicine={


name:
document.getElementById("medicineName").value,


category:
document.getElementById("category").value,


quantity:
document.getElementById("quantity").value,


price:
document.getElementById("price").value,


supplier:
document.getElementById("supplier").value,


manufacture:
document.getElementById("manufacture").value,


expiry:
document.getElementById("expiry").value


};





let inventory =
JSON.parse(
localStorage.getItem("inventory")
)
||
[];





inventory.push(medicine);



localStorage.setItem(
"inventory",
JSON.stringify(inventory)
);





showPopup();




form.reset();


imagePreview.src="";



});







// ============================
// SUCCESS POPUP
// ============================


function showPopup(){


const popup =
document.getElementById("popup");



popup.style.display="block";



setTimeout(()=>{


popup.style.display="none";


},3000);



}