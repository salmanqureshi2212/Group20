/**
 * MedEasy — shared page navigation (static prototype).
 */
(function () {
  'use strict';

  var P = {
    splash: '../splash-screen/index.html',
    home: '../home-dashboard/index.html',
    search: '../medicine-search-results/index.html',
    upload: '../onboarding-ai-upload/index.html',
    prescriptionScan: '../ai-prescription-scan/index.html',
    cart: '../shopping-cart/index.html',
    checkoutAddress: '../checkout-delivery-address/index.html',
    checkoutPayment: '../checkout-payment-method/index.html',
    orderSuccess: '../order-success/index.html',
    orderHistory: '../order-history-support/index.html',
    orderTracking: '../live-order-tracking/index.html',
    orderFeedback: '../order-feedback-complaints/index.html',
    medicineDetails: '../medicine-details/index.html',
    profile: '../customer-profile-dashboard/index.html',
    pharmacies: '../pharmacies-medicines/index.html',
    pharmacyDetails: '../pharmacy-details-medicine-list/index.html'
  };

  var NAV_ICONS = {
    home: P.home,
    search: P.search,
    description: P.upload,
    shopping_bag: P.orderHistory,
    person: P.profile
  };

  var BACK = {
    'shopping-cart': P.home,
    'ai-prescription-scan': P.upload,
    'checkout-delivery-address': P.cart,
    'checkout-payment-method': P.checkoutAddress,
    'medicine-details': P.search,
    'medicine-search-results': P.home,
    'order-feedback-complaints': P.orderHistory,
    'pharmacy-details-medicine-list': P.pharmacies
  };

  function go(url) {
    window.location.href = url;
  }

  function pageId() {
    var path = window.location.pathname.replace(/\\/g, '/');
    var match = path.match(/\/pages\/([^/]+)\//);
    return match ? match[1] : '';
  }

  function iconText(el) {
    if (!el) return '';
    var icon = el.querySelector('.material-symbols-outlined');
    if (icon) return icon.textContent.trim();
    return el.textContent.trim();
  }

  function medicineDetailUrl(el) {
    var target = el.closest('[data-product-id]') || el;
    var id = target.getAttribute('data-product-id');
    return id ? P.medicineDetails + '?id=' + encodeURIComponent(id) : P.medicineDetails;
  }

  function wireMedicineDetail(el, stopProp) {
    if (!el || el.dataset.navWired === '1') return;
    el.dataset.navWired = '1';
    el.style.cursor = 'pointer';
    el.addEventListener('click', function (e) {
      if (stopProp) {
        e.preventDefault();
        e.stopPropagation();
      }
      go(medicineDetailUrl(el));
    });
  }

  function pharmacyDetailUrl(el) {
    var target = el.closest('[data-pharmacy-id]') || el;
    var id = target.getAttribute('data-pharmacy-id');
    return id ? P.pharmacyDetails + '?id=' + encodeURIComponent(id) : P.pharmacyDetails;
  }

  function wirePharmacyDetail(el) {
    if (!el || el.dataset.navWired === '1') return;
    el.dataset.navWired = '1';
    el.style.cursor = 'pointer';
    el.addEventListener('click', function (e) {
      if (e.target.closest('button') && e.target.closest('button').textContent.trim() === 'Add') return;
      go(pharmacyDetailUrl(el));
    });
  }

  function wireNav(el, url, stopProp) {
    if (!el || el.dataset.navWired === '1') return;
    el.dataset.navWired = '1';
    el.style.cursor = 'pointer';
    if (el.tagName === 'A') {
      el.href = url;
      return;
    }
    el.addEventListener('click', function (e) {
      if (stopProp) {
        e.preventDefault();
        e.stopPropagation();
      }
      go(url);
    });
  }

  function isBottomNavBar(el) {
    var container = el.closest('nav.fixed.bottom-0, footer.fixed.bottom-0');
    if (!container) return false;
    var t = container.textContent.replace(/\s+/g, ' ');
    return /\bHome\b/.test(t) &&
      (/\bSearch\b/.test(t) || /\bUpload\b/.test(t) || /\bProfile\b/.test(t) || /\bOrders\b/.test(t) || /\bCart\b/.test(t));
  }

  function wireButtonsContaining(text, url, stopProp) {
    document.querySelectorAll('button, a').forEach(function (btn) {
      if (isBottomNavBar(btn)) return;
      var label = btn.textContent.replace(/\s+/g, ' ').trim();
      if (label.indexOf(text) !== -1) wireNav(btn, url, stopProp !== false);
    });
  }

  function wireBottomNav() {
    document.querySelectorAll('nav.fixed.bottom-0, footer.fixed.bottom-0').forEach(function (nav) {
      nav.querySelectorAll('a, button, div.flex.flex-col').forEach(function (item) {
        var icon = iconText(item);
        var label = item.textContent.replace(/\s+/g, ' ').trim();
        if (icon === 'shopping_bag' && label.indexOf('Cart') !== -1) {
          wireNav(item, P.cart);
          return;
        }
        if (NAV_ICONS[icon]) wireNav(item, NAV_ICONS[icon]);
      });
    });
  }

  function wireBackButton() {
    var backUrl = BACK[pageId()];
    if (!backUrl) return;
    document.querySelectorAll('header button, nav.fixed button').forEach(function (btn) {
      if (iconText(btn) === 'arrow_back') wireNav(btn, backUrl, true);
    });
  }

  function wireHeaderCart() {
    document.querySelectorAll('header button').forEach(function (btn) {
      if (iconText(btn) === 'shopping_cart') wireNav(btn, P.cart, true);
    });
  }

  function wireAnchorByText(selector, map) {
    document.querySelectorAll(selector).forEach(function (a) {
      var t = a.textContent.trim();
      Object.keys(map).forEach(function (key) {
        if (t.indexOf(key) !== -1) a.href = map[key];
      });
    });
  }

  function wirePageActions() {
    var id = pageId();

    if (id === 'home-dashboard') {
      document.querySelectorAll('section .grid > div').forEach(function (el) {
        var t = el.textContent;
        if (t.indexOf('Upload Prescription') !== -1) wireNav(el, P.upload);
        if (t.indexOf('Reorder Medicines') !== -1) wireNav(el, P.cart);
      });
      document.querySelectorAll('section .flex-shrink-0.group.cursor-pointer').forEach(function (el) {
        wireNav(el, P.search);
      });
      document.querySelectorAll('section .group.cursor-pointer.hover\\:shadow-md').forEach(function (el) {
        if (el.classList.contains('pharmacy-card') || el.getAttribute('data-pharmacy-id')) {
          wirePharmacyDetail(el);
        } else {
          wireNav(el, P.search);
        }
      });
      document.querySelectorAll('section .group.overflow-hidden').forEach(function (el) {
        if (el.querySelector('button') && el.textContent.indexOf('Add to Cart') !== -1) {
          wireMedicineDetail(el);
        }
      });
      document.querySelectorAll('section .group.overflow-hidden button').forEach(function (btn) {
        if (btn.textContent.indexOf('Add to Cart') !== -1) wireNav(btn, P.cart, true);
      });
      document.querySelectorAll('section button').forEach(function (btn) {
        if (btn.textContent.trim().indexOf('See All') !== -1) wireNav(btn, P.pharmacies, true);
      });
      var searchInput = document.querySelector('input[placeholder*="Search medicines"]');
      if (searchInput) {
        searchInput.addEventListener('keydown', function (e) {
          if (e.key === 'Enter') {
            var q = encodeURIComponent(searchInput.value.trim());
            go(P.search + (q ? '?q=' + q : ''));
          }
        });
      }
    }

    if (id === 'shopping-cart') {
      wireButtonsContaining('Proceed to Checkout', P.checkoutAddress, true);
      wireButtonsContaining('Upload Rx', P.prescriptionScan, true);
      document.querySelectorAll('header button').forEach(function (btn) {
        if (iconText(btn) === 'help') wireNav(btn, P.orderHistory, true);
      });
    }

    if (id === 'checkout-delivery-address') {
      wireButtonsContaining('Continue to Payment', P.checkoutPayment, true);
      document.querySelectorAll('.cursor-pointer').forEach(function (el) {
        if (el.textContent.indexOf('4242') !== -1) wireNav(el, P.checkoutPayment);
      });
    }

    if (id === 'checkout-payment-method') {
      wireButtonsContaining('Place Order', P.orderSuccess, true);
    }

    if (id === 'order-success') {
      document.querySelectorAll('header button').forEach(function (btn) {
        if (iconText(btn) === 'close') wireNav(btn, P.home, true);
      });
      wireButtonsContaining('Track Order', P.orderTracking, true);
      wireButtonsContaining('Continue Shopping', P.home, true);
    }

    if (id === 'onboarding-ai-upload') {
      document.querySelectorAll('header button').forEach(function (btn) {
        if (btn.textContent.trim() === 'Skip') wireNav(btn, P.home, true);
      });
      wireButtonsContaining('Next', P.prescriptionScan, true);
    }

    if (id === 'ai-prescription-scan') {
      document.querySelectorAll('button').forEach(function (btn) {
        if (btn.textContent.indexOf('Add to Cart') !== -1) wireNav(btn, P.cart, true);
      });
      document.querySelectorAll('header button').forEach(function (btn) {
        if (iconText(btn) === 'help') wireNav(btn, P.orderHistory, true);
      });
    }

    if (id === 'pharmacies-medicines') {
      document.querySelectorAll('.pharmacy-card').forEach(function (card) {
        wirePharmacyDetail(card);
        card.querySelectorAll('button').forEach(function (btn) {
          if (btn.textContent.trim() === 'Add') wireNav(btn, P.cart, true);
        });
      });
    }

    if (id === 'pharmacy-details-medicine-list') {
      document.querySelectorAll('section .grid button').forEach(function (btn) {
        if (iconText(btn) === 'add') wireNav(btn, P.cart, true);
      });
    }

    if (id === 'medicine-search-results') {
      document.querySelectorAll('.search-product-card').forEach(function (card) {
        wireMedicineDetail(card);
        card.querySelectorAll('button').forEach(function (btn) {
          if (btn.textContent.indexOf('ADD') !== -1 || btn.textContent.indexOf('Add to Cart') !== -1) {
            wireNav(btn, P.cart, true);
          }
        });
      });
      wireAnchorByText('aside a[href="#"]', {
        'My Records': P.profile,
        Search: P.search,
        Pharmacies: P.pharmacies,
        Payments: P.checkoutPayment,
        Settings: P.profile
      });
      document.querySelectorAll('aside div').forEach(function (el) {
        if (el.textContent.indexOf('Alex Johnson') !== -1) wireNav(el, P.profile);
      });
    }

    if (id === 'medicine-details') {
      wireButtonsContaining('Add to Cart', P.cart, true);
      document.querySelectorAll('button').forEach(function (btn) {
        if (btn.textContent.indexOf('View All') !== -1) wireNav(btn, P.search, true);
      });
      document.querySelectorAll('section .group.cursor-pointer, section .group').forEach(function (el) {
        if (el.querySelector('img') && el.textContent.indexOf('Add') !== -1 && !el.closest('header')) {
          wireMedicineDetail(el);
        }
      });
    }

    if (id === 'customer-profile-dashboard') {
      document.querySelectorAll('button.bento-card').forEach(function (btn) {
        var t = btn.textContent;
        if (t.indexOf('Orders') !== -1) wireNav(btn, P.orderHistory);
        if (t.indexOf('Prescriptions') !== -1) wireNav(btn, P.prescriptionScan);
      });
      document.querySelectorAll('button').forEach(function (btn) {
        if (btn.textContent.trim() === 'View All') wireNav(btn, P.orderHistory, true);
        if (btn.textContent.indexOf('Logout') !== -1) wireNav(btn, P.splash, true);
      });
      document.querySelectorAll('.divide-y .p-md').forEach(function (row) {
        if (row.textContent.indexOf('Delivered') !== -1) wireNav(row, P.orderHistory);
        if (row.textContent.indexOf('Prescription Uploaded') !== -1) wireNav(row, P.prescriptionScan);
      });
      wireAnchorByText('a[href="#"]', {
        'Address Book': P.checkoutAddress,
        'Payment Methods': P.checkoutPayment,
        Notifications: P.orderHistory,
        'Password': P.profile,
        'Active Sessions': P.profile
      });
      document.querySelectorAll('.cursor-pointer.rounded-xl, .rounded-xl.cursor-pointer').forEach(function (el) {
        if (el.textContent.indexOf('Help Center') !== -1) wireNav(el, P.orderFeedback);
        if (el.textContent.indexOf('Terms') !== -1) wireNav(el, P.home);
      });
    }

    if (id === 'live-order-tracking') {
      wireButtonsContaining('Shop Now', P.home, true);
      wireButtonsContaining('Contact Support', P.orderFeedback, true);
    }

    if (id === 'order-history-support') {
      wireAnchorByText('header a[href="#"]', {
        Dashboard: P.home,
        'My Orders': P.orderHistory,
        'Healthcare Store': P.home,
        'Help & Support': P.orderFeedback
      });
      wireAnchorByText('aside a[href="#"]', {
        'My Profile': P.profile,
        'My Addresses': P.checkoutAddress,
        Payments: P.checkoutPayment,
        'My Orders': P.orderHistory,
        Reminders: P.orderHistory,
        Notifications: P.orderHistory,
        Logout: P.splash
      });
      document.querySelectorAll('header .cursor-pointer, aside .cursor-pointer').forEach(function (el) {
        if (el.textContent.indexOf('Arjun Mehta') !== -1) wireNav(el, P.profile);
      });
      document.querySelectorAll('button').forEach(function (btn) {
        var t = btn.textContent.replace(/\s+/g, ' ').trim();
        if (t.indexOf('Track Live') !== -1 || t.indexOf('View Details') !== -1) wireNav(btn, P.orderTracking, true);
        if (t.indexOf('Give Feedback') !== -1 || t.indexOf('File Complaint') !== -1) wireNav(btn, P.orderFeedback, true);
        if (t.indexOf('Reorder') !== -1) wireNav(btn, P.cart, true);
      });
    }
  }

  function wireSplashRedirect() {
    if (pageId() !== 'splash-screen') return;
    setTimeout(function () {
      go(P.upload);
    }, 3500);
  }

  function init() {
    wireBottomNav();
    wireBackButton();
    wireHeaderCart();
    wirePageActions();
    wireSplashRedirect();

    document.querySelectorAll('a[href="#"]').forEach(function (a) {
      if (a.closest('nav.fixed.bottom-0, footer.fixed.bottom-0')) {
        var icon = iconText(a);
        if (NAV_ICONS[icon]) a.href = NAV_ICONS[icon];
      }
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
