// Simple quantity interaction logic
        document.querySelectorAll('button').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const icon = btn.querySelector('.material-symbols-outlined');
                if (!icon) return;
                const action = icon.textContent.trim();
                if (action !== 'add' && action !== 'remove') return;

                const span = btn.parentElement.querySelector('span.px-md');
                if (!span) return;

                let val = parseInt(span.textContent, 10);
                if (action === 'add') {
                    val++;
                } else if (val > 1) {
                    val--;
                }
                span.textContent = val;
            });
        });
